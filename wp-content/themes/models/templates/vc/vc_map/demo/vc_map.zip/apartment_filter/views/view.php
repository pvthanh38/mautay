<?php //if ( !isset( $atts['title'] ) ) return; ?>

<?php
    //$items = vc_param_group_parse_atts( $atts['content_view'] );
	//$image = wp_get_attachment_image_url($atts['img'], 'full');
	$terms = get_terms( array( 'taxonomy' => 'apartment-cat', 'hide_empty' => false,) );
	print_r($terms);

?>
<div class="gasha-main-content ">
    <div class="apm-bg">
        <div class="apm-block-1">
            <div class="container">
                <div class="row">
                    <form action="">
                        <div class="col-md-4">
                            <div class="search">
                                <span><i class="fas fa-search"></i></span>
                                <input type="text" id="search" placeholder="Search now...">
                                <input type="button" id="button" value="SEARCH">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="type">
                                <span>Type</span>
                                <select name="" id="type">
                                    <option>New</option>
                                    <option>A</option>
                                    <option>Type 2</option>
                                    <option>Type 3</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="price">
                                <span>Price</span>
                                <select name="" id="price">
									<option value="0">All</option>
									<option value="1">< 20,000,000 ₫</option>
                                    <option value="2">20,000,000 ₫ - 50,000,000 ₫</option>
                                    <option value="3">50,000,000 ₫ - 100,000,000 ₫</option>
                                    <option value="4">> 100,000,000 ₫</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="sort">
                                <span>Sorting</span>
                                <select name="" id="sort">
                                    <option value="0">New</option>
                                    <option value="1">Old</option>
                                    <option value="2">A-Z</option>
                                    <option value="3">Z-A</option>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
    </div>
</div>